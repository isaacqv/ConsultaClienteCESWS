package pe.com.claro.eai.ws.postventa.consultaclientecesws.typesiptv;

public class IptvResquest {
	
	private String customer;
	
	private String tipo;

	public String getCustomer() {
		return customer;
	}

	public void setCustomer(String customer) {
		this.customer = customer;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	
}
