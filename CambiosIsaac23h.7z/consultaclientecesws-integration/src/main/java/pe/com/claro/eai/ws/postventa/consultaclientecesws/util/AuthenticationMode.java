package pe.com.claro.eai.ws.postventa.consultaclientecesws.util;

public enum AuthenticationMode {
	BASIC_AUTH, SHARED_SECRET_KEY
}
