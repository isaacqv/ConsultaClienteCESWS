@javax.xml.bind.annotation.XmlSchema(namespace = "http://claro.com.pe/eai/ws/postventa/consultaclientecesws/types")
package pe.com.claro.eai.ws.postventa.consultaclientecesws.types;
