@javax.xml.bind.annotation.XmlSchema(namespace = "http://claro.com.pe/eai/ws/baseschema", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package pe.com.claro.eai.ws.baseschema;
