package pe.com.claro.eai.ws.postventa.consultaclientecesws.bean;

import java.util.List;

public class ListaRegla {
	
	private List<Regla> listRegla;

	public List<Regla> getListRegla() {
		return listRegla;
	}

	public void setListRegla(List<Regla> listRegla) {
		this.listRegla = listRegla;
	}
	
	
}
