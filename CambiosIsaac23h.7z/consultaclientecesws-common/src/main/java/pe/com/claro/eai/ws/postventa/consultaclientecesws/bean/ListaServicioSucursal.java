package pe.com.claro.eai.ws.postventa.consultaclientecesws.bean;

import java.util.List;

public class ListaServicioSucursal {

	private List<ServicioSucursal> listServicioSucursal;

	public List<ServicioSucursal> getListServicioSucursal() {
		return listServicioSucursal;
	}

	public void setListServicioSucursal(List<ServicioSucursal> listServicioSucursal) {
		this.listServicioSucursal = listServicioSucursal;
	}
}
