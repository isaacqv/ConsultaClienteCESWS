package pe.com.claro.eai.ws.postventa.consultaclientecesws.bean;

public class EstadoServicio {

	private String i_faspid;
	private String v_faspmessage;
	private String v_seraffected;

	public String getI_faspid() {
		return i_faspid;
	}

	public void setI_faspid(String i_faspid) {
		this.i_faspid = i_faspid;
	}

	public String getV_faspmessage() {
		return v_faspmessage;
	}

	public void setV_faspmessage(String v_faspmessage) {
		this.v_faspmessage = v_faspmessage;
	}

	public String getV_seraffected() {
		return v_seraffected;
	}

	public void setV_seraffected(String v_seraffected) {
		this.v_seraffected = v_seraffected;
	}
}
