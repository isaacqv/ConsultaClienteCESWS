package pe.com.claro.eai.ws.postventa.consultaclientecesws.bean;

import java.util.List;

public class ListaDatosProblema {

	private List<DatosProblema> listDatosProblema;

	public List<DatosProblema> getListDatosProblema() {
		return listDatosProblema;
	}

	public void setListDatosProblema(List<DatosProblema> listDatosProblema) {
		this.listDatosProblema = listDatosProblema;
	}
}
