package pe.com.claro.eai.ws.postventa.consultaclientecesws.bean;

import java.util.List;

public class ListaSucursal {

	private List<Sucursal> listaSucursal;

	public List<Sucursal> getListaSucursal() {
		return listaSucursal;
	}

	public void setListaSucursal(List<Sucursal> listaSucursal) {
		this.listaSucursal = listaSucursal;
	}
}