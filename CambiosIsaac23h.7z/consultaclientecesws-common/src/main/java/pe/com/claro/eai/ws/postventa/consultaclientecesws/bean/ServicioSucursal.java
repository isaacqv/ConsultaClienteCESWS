package pe.com.claro.eai.ws.postventa.consultaclientecesws.bean;

public class ServicioSucursal {

	private String tipo_servicio;
	private String codinssrv;
	private String numero;
	private String servicio;
	private String valido_desde;

	public String getTipo_servicio() {
		return tipo_servicio;
	}

	public void setTipo_servicio(String tipo_servicio) {
		this.tipo_servicio = tipo_servicio;
	}

	public String getCodinssrv() {
		return codinssrv;
	}

	public void setCodinssrv(String codinssrv) {
		this.codinssrv = codinssrv;
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public String getServicio() {
		return servicio;
	}

	public void setServicio(String servicio) {
		this.servicio = servicio;
	}

	public String getValido_desde() {
		return valido_desde;
	}

	public void setValido_desde(String valido_desde) {
		this.valido_desde = valido_desde;
	}

}