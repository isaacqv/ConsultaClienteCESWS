package pe.com.claro.eai.ws.postventa.consultaclientecesws.bean;

import java.util.List;

public class ListaJanus {

	private List<Janus> listJanus;

	public List<Janus> getListJanus() {
		return listJanus;
	}

	public void setListJanus(List<Janus> listJanus) {
		this.listJanus = listJanus;
	}

}
