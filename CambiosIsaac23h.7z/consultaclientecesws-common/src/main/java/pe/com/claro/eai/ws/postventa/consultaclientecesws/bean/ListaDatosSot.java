package pe.com.claro.eai.ws.postventa.consultaclientecesws.bean;

import java.util.List;

public class ListaDatosSot {

	private List<DatosSot> listDatosSot;

	public List<DatosSot> getListDatosSot() {
		return listDatosSot;
	}

	public void setListDatosSot(List<DatosSot> listDatosSot) {
		this.listDatosSot = listDatosSot;
	}
}
