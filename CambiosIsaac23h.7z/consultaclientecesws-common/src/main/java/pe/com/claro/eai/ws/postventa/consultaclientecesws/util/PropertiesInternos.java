package pe.com.claro.eai.ws.postventa.consultaclientecesws.util;

public class PropertiesInternos {

	public static final String PUNTO = ".";
	public static final String SALTOLINEA = "\n";
	public static final String STRING_EMPTY = "";
	public static final String NULL = null;
	public static final Object NULL_OBJECT = null;
	public static final String STICK = "|";

}