package pe.com.claro.eai.ws.postventa.consultaclientecesws.bean;

import java.util.List;

public class ListaSeaChange {

	private List<SeaChange> listSeaChange;

	public List<SeaChange> getListSeaChange() {
		return listSeaChange;
	}

	public void setListSeaChange(List<SeaChange> listSeaChange) {
		this.listSeaChange = listSeaChange;
	}

}
