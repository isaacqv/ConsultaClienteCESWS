package pe.com.claro.eai.ws.postventa.consultaclientecesws.util;

public class ConstantesValidacion {

	public static final String SIZE = "El campo debe de tener de {min} a {max} caracteres";
	public static final String SIZE_MAX = "El campo debe de tener maximo {max} caracteres";
	public static final String NOT_NULL = "El campo debe de tener un valor";

}
