package pe.com.claro.eai.ws.postventa.consultaclientecesws.bean;

public class DetalleSucursalDTH {

	private String codcli;
	private String codsuc;
	private String numslc;
	private String direccion;
	private String codsolot;
	private String ubigeo;
	private String departamento;
	private String provincia;
	private String distrito;
	private String internet;
	private String telefonia;
	private String cable;
	private String estado;
	private String plataforma;

	public String getCodcli() {
		return codcli;
	}

	public void setCodcli(String codcli) {
		this.codcli = codcli;
	}

	public String getCodsuc() {
		return codsuc;
	}

	public void setCodsuc(String codsuc) {
		this.codsuc = codsuc;
	}

	public String getNumslc() {
		return numslc;
	}

	public void setNumslc(String numslc) {
		this.numslc = numslc;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public String getCodsolot() {
		return codsolot;
	}

	public void setCodsolot(String codsolot) {
		this.codsolot = codsolot;
	}

	public String getUbigeo() {
		return ubigeo;
	}

	public void setUbigeo(String ubigeo) {
		this.ubigeo = ubigeo;
	}

	public String getDepartamento() {
		return departamento;
	}

	public void setDepartamento(String departamento) {
		this.departamento = departamento;
	}

	public String getProvincia() {
		return provincia;
	}

	public void setProvincia(String provincia) {
		this.provincia = provincia;
	}

	public String getDistrito() {
		return distrito;
	}

	public void setDistrito(String distrito) {
		this.distrito = distrito;
	}

	public String getInternet() {
		return internet;
	}

	public void setInternet(String internet) {
		this.internet = internet;
	}

	public String getTelefonia() {
		return telefonia;
	}

	public void setTelefonia(String telefonia) {
		this.telefonia = telefonia;
	}

	public String getCable() {
		return cable;
	}

	public void setCable(String cable) {
		this.cable = cable;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public String getPlataforma() {
		return plataforma;
	}

	public void setPlataforma(String plataforma) {
		this.plataforma = plataforma;
	}

}
