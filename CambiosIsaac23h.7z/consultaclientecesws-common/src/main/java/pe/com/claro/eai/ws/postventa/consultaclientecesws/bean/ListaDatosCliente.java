package pe.com.claro.eai.ws.postventa.consultaclientecesws.bean;

import java.util.List;

public class ListaDatosCliente {

	private List<DatosCliente> listDatosCliente;

	public List<DatosCliente> getListDatosCliente() {
		return listDatosCliente;
	}

	public void setListDatosCliente(List<DatosCliente> listDatosCliente) {
		this.listDatosCliente = listDatosCliente;
	}

	
}
