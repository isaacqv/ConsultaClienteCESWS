package pe.com.claro.eai.ws.postventa.consultaclientecesws.bean;

public class Tecnologia {

	private String tecnologia;
	private String customer_id;
	private String co_id;
	private String plan;
	private String numero;
	private String nro_pago;
	private String distrito;
	private String direccion;
	private String estado;
	private String motivo_estado;
	private String valido_desde;

	public String getTecnologia() {
		return tecnologia;
	}

	public void setTecnologia(String tecnologia) {
		this.tecnologia = tecnologia;
	}

	public String getCustomer_id() {
		return customer_id;
	}

	public void setCustomer_id(String customer_id) {
		this.customer_id = customer_id;
	}

	public String getCo_id() {
		return co_id;
	}

	public void setCo_id(String co_id) {
		this.co_id = co_id;
	}

	public String getPlan() {
		return plan;
	}

	public void setPlan(String plan) {
		this.plan = plan;
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public String getNro_pago() {
		return nro_pago;
	}

	public void setNro_pago(String nro_pago) {
		this.nro_pago = nro_pago;
	}

	public String getDistrito() {
		return distrito;
	}

	public void setDistrito(String distrito) {
		this.distrito = distrito;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public String getMotivo_estado() {
		return motivo_estado;
	}

	public void setMotivo_estado(String motivo_estado) {
		this.motivo_estado = motivo_estado;
	}

	public String getValido_desde() {
		return valido_desde;
	}

	public void setValido_desde(String valido_desde) {
		this.valido_desde = valido_desde;
	}
}
