package pe.com.claro.eai.ws.postventa.consultaclientecesws.bean;

import java.util.List;

public class ListaFalla {

	private List<Falla> listFalla;

	public List<Falla> getListFalla() {
		return listFalla;
	}

	public void setListFalla(List<Falla> listFalla) {
		this.listFalla = listFalla;
	}

}
