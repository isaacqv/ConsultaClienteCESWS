package pe.com.claro.eai.ws.postventa.consultaclientecesws.bean;

import java.util.List;

public class ListaClientePorNombre {

	private List<ClientePorNombre> listClientePorNombre;

	public List<ClientePorNombre> getListClientePorNombre() {
		return listClientePorNombre;
	}

	public void setListClientePorNombre(List<ClientePorNombre> listClientePorNombre) {
		this.listClientePorNombre = listClientePorNombre;
	}
}
