package pe.com.claro.eai.ws.postventa.consultaclientecesws.bean;

import java.util.List;

public class ListaDatosInfVar {

	private List<DatosInfVar> listDatosInfVar;

	public List<DatosInfVar> getListDatosInfVar() {
		return listDatosInfVar;
	}

	public void setListDatosInfVar(List<DatosInfVar> listDatosInfVar) {
		this.listDatosInfVar = listDatosInfVar;
	}
}
