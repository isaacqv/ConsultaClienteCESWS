package pe.com.claro.eai.ws.postventa.consultaclientecesws.bean;

import java.util.List;

public class ListaCliente {

	private List<Cliente> listCliente;

	public List<Cliente> getListCliente() {
		return listCliente;
	}

	public void setListCliente(List<Cliente> listCliente) {
		this.listCliente = listCliente;
	}
}
