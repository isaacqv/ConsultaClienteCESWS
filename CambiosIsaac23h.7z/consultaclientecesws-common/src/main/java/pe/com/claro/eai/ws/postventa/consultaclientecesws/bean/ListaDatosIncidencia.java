package pe.com.claro.eai.ws.postventa.consultaclientecesws.bean;

import java.util.List;

public class ListaDatosIncidencia {

	private List<DatosIncidencia> listDatosIncidencia;

	public List<DatosIncidencia> getListDatosIncidencia() {
		return listDatosIncidencia;
	}

	public void setListDatosIncidencia(List<DatosIncidencia> listDatosIncidencia) {
		this.listDatosIncidencia = listDatosIncidencia;
	}
}
